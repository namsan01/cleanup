export const SERVER_URL = "";
// export const SERVER_URL = "http://192.168.0.144:5215";
