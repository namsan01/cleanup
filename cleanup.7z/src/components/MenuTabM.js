import React from "react";
import {
  MenuTabDelete,
  MenuTabEdit,
  MenuTabStyle,
} from "../styles/menutabstyle";
import CreateEditList from "./CreateEditList";

const MenuTab = (props, isPopupOpen) => {
  const pk = props.pk;
  const handleClick = props.handleClick;
  return (
    <MenuTabStyle>
      <MenuTabEdit onClick={isPopupOpen}>
        {isPopupOpen && <CreateEditList />}
        <h3>수정하기</h3>
      </MenuTabEdit>
      <MenuTabDelete
        onClick={() => {
          handleClick(pk);
        }}
      >
        <h3>삭제하기</h3>
      </MenuTabDelete>
    </MenuTabStyle>
  );
};

export default MenuTab;
